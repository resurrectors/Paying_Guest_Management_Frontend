import React from 'react'

const Logout = () => {
  return (
    <div>
      You have been Logged Out!
    </div>
  )
}

export default Logout
